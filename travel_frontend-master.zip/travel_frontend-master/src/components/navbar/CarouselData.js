export const data = [
    {
        image : "http://gfxpartner.com/Frolic/images/slide01.jpg"
    },
    {
        image : "http://gfxpartner.com/Frolic/images/slide02.jpg"
    },
    {
        image : "http://gfxpartner.com/Frolic/images/slide03.jpg"
    },
    {
        image : "http://gfxpartner.com/Frolic/images/slide04.jpg"
    },
]