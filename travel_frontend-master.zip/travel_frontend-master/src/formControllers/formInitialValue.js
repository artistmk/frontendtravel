const initialValues = [{
    email : "",
    password : ""
},
{
    name : "",
    email : "",
    password : "",
    conformPassword : ""
},
{
    otp : ""
}
]

module.exports = initialValues;